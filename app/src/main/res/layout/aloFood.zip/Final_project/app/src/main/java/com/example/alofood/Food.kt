package com.example.alofood

data class Food(

    val txtSub: String,
    val txtCity: String,
    val txtPrice: String,
    val txtDistance: String,
    val urlImg: String,
    val numOfRating: Int,
    val rating: Float


){



}
